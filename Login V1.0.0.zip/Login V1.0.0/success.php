<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "app01";
$conn = new mysqli($servername, $username, $password, $dbname);
echo '<script>console.log("successful connection")</script>';
$passwordhash = $_GET["passwordhash"];
$user = $_GET["username"];
$adminsql = $conn->query("SELECT * FROM users WHERE rank = 'admin' AND username = '$user'");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if (isset($_GET["logintrue"]) && $_GET["logintrue"] == md5("true") && $_GET["passwordhash"] == $passwordhash) {
	echo "<h2>Welcome, $user.</h2> ";
} else {
	header("Location: index.php");
}
if ($adminsql->num_rows > 0){
	echo "<h3>You are an admin of this site.</h3>";
}



?>
 <form>
 	<button action="header('Location: index.php');">Logout</button>
 </form>