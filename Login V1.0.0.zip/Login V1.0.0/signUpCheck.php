<?php

//Connect to SQL

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "app01";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo '<script>console.log("successful connection")</script>';


$username = $_POST["username"];
$password = $_POST["password"];
$email = $_POST["email"];
$rank = "member"; 

$result = ($conn->query("SELECT * FROM users
WHERE username = '" . "$username" . "'"));

//No special characters

$checkinfo = $_POST["username"] . $_POST["password"];
$specialchar1 = stripos($checkinfo, ';') !== false;
$specialchar2 = stripos($checkinfo, '"') !== false;
$specialchar3 = stripos($checkinfo, "'") !== false;
$specialchar4 = stripos($checkinfo, ".") !== false;

if ($specialchar1 || $specialchar2 || $specialchar3 || $specialchar4){
	$specialchar = 1;
}

if ($specialchar = 1) {
	header("Location: signUp.php?specialchar=1");
} else{

//Short credentials

if (strlen($_POST["username"]) < 4) {
	header("Location: signUp.php?shortname=1");
} elseif (strlen($_POST["password"]) < 6) {
	header("Location: signUp.php?shortpassword=1");
} else {

  //Username Taken

  if ($result->num_rows > 0) {
    header("Location: signUp.php?taken=1");
  } elseif (!empty($username) && !empty($password) && !empty($email)) {

        //Setup SQL

  	    $sql = "INSERT INTO users (username, password, email, rank)
        VALUES ('$username', '$password', '$email', '$rank');";

	    if ($conn->query($sql) === TRUE) {

          //Account created

          sleep(1);
          header("Location: index.php?new=1");
        } else {

           //Catche SQL connection error

           echo "Error: " . $sql . "<br>" . $conn->error;
        }

      } else {

       //Empty field

        header("Location: signUp.php?empty=true");
    }

}
}

$conn->close();

?>